{
    "Workflow.DeleteQuestion": "您确定要永久删除这项吗？",
    "Workflow.EMBARGOMESSAGETIME": "这个页面已保存的草稿会在今天<a>%s</a>自动发布",
    "Workflow.EMBARGOMESSAGEDATE": "这个页面已保存的草稿会在<a>%s</a>自动发布",
    "Workflow.EMBARGOMESSAGEDATETIME": "这个页面已保存的草稿会在<a>%s  %s</a>自动发布",
    "Workflow.ProcessError": "无法处理工作流程"
}