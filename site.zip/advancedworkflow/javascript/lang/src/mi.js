{
    "Workflow.DeleteQuestion": "Me muku pūmau tēnei?",
    "Workflow.EMBARGOMESSAGETIME": "Ka whakaputa aunoatia anō i tēnei rā ngā hukihuki kua tiakina o tēnei whārangi <a>%s i %s</a>",
    "Workflow.EMBARGOMESSAGEDATE": "Ka whakaputa aunoatia ngā hukihuki kua tiakina o tēnei whārangi <a>%s i %s</a>",
    "Workflow.EMBARGOMESSAGEDATETIME": "Ka whakaputa aunoatia ngā hukihuki kua tiakina o tēnei whārangi <a>%s i %s</a>",
    "Workflow.ProcessError": "Kāore i taea te tukatuka te reremahi"
}