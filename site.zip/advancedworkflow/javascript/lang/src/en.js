{
	"Workflow.DeleteQuestion": "Are you sure you want to permanently delete this?",
	"Workflow.EMBARGOMESSAGETIME": "Saved drafts of this page will auto publish today at <a>%s</a>",
	"Workflow.EMBARGOMESSAGEDATE": "Saved drafts of this page will auto publish on <a>%s</a>",
	"Workflow.EMBARGOMESSAGEDATETIME": "Saved drafts of this page will auto publish on <a>%s at %s</a>",
	"Workflow.ProcessError": "Could not process workflow"
}