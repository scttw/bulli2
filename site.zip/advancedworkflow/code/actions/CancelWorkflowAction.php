<?php
/**
 * Description
 *
 * @author     marcus@silverstripe.com.au
 * @license    BSD License (http://silverstripe.org/bsd-license/)
 * @package    advancedworkflow
 * @subpackage actions
 */
class CancelWorkflowAction extends WorkflowAction {
    public static $icon = 'advancedworkflow/images/cancel.png';
}