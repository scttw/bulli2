{
    "Workflow.DeleteQuestion": "هل أنت متأكد من كونك تريد حذف هذا بشكل دائم؟",
    "Workflow.EMBARGOMESSAGETIME": "سوف تنشر المسودات المحفوظة لهذه الصفحة تلقائيا اليوم في <a>%s</a>",
    "Workflow.EMBARGOMESSAGEDATE": "سوف تنشر المسودات المحفوظة لهذه الصفحة تلقائيا على <a>%s</a>",
    "Workflow.EMBARGOMESSAGEDATETIME": "سوف تنشر المسودات المحفوظة لهذه الصفحة تلقائيا على <a>%s في %s</a>",
    "Workflow.ProcessError": "لا يمكن تسيير العملية حتى النهاية"
}