{
    "Workflow.DeleteQuestion": "Ĉi vi vere volas porĉiame forigi ĉi tiun dosieron?",
    "Workflow.EMBARGOMESSAGETIME": "Konservitaj malnetoj de la paĝo aŭtomate publikiĝos hodiaŭ je  <a>%s</a>",
    "Workflow.EMBARGOMESSAGEDATE": "Konservitaj malnetoj de la paĝo aŭtomate publikiĝos je <a>%s</a>",
    "Workflow.EMBARGOMESSAGEDATETIME": "Konservitaj malnetoj de la paĝo aŭtomate publikiĝos ĉe <a>%s je %s</a>",
    "Workflow.ProcessError": "Ne povis trakti la laborfluon"
}